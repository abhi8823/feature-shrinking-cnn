# Feature-Shrinking CNN

A lightweight grayscale-image CNN built with TensorFlow/Keras using the **Sequential API**. It reduces spatial dimensions through convolution strides and valid padding, without using a pooling layer.

## Architecture

| Layer | Configuration | Output shape |
|---|---|---|
| Input | 28 × 28 × 1 | 28 × 28 × 1 |
| Conv2D 1 | 16 filters, 3 × 3, stride 2, same, ReLU | 14 × 14 × 16 |
| Conv2D 2 | 32 filters, 3 × 3, stride 1, valid, ReLU | 12 × 12 × 32 |
| Flatten | — | 4,608 |
| Dense | 10 units, softmax | 10 |

**No pooling layer is used.** The first convolution downsamples the image from 28 × 28 to 14 × 14. The second convolution reduces it to 12 × 12.

## Requirements

- Python 3.9+
- TensorFlow 2.x

Install dependencies:

```bash
pip install -r requirements.txt
```

## Run

```bash
python model.py
```

The script prints the model summary and performs a small forward-pass smoke test using a random grayscale image. The output contains 10 class probabilities.

## Notes

This exercise defines the requested architecture; it does not train the model on a dataset. The final Dense layer is configured for 10-class classification.
